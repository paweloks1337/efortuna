import { useState } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { CheckCircle2, AlertCircle, Loader2, Target } from 'lucide-react';

export default function BetForm({ match, existingBet, onBetPlaced }) {
  const { user } = useAuth();
  const [winner, setWinner] = useState(existingBet?.predicted_winner || '');
  const [scoreA, setScoreA] = useState(existingBet?.predicted_score_a ?? '');
  const [scoreB, setScoreB] = useState(existingBet?.predicted_score_b ?? '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const startTime = new Date(match.start_time);
  const isClosed = new Date() >= startTime || match.status !== 'upcoming';

  if (!user) {
    return (
      <div className="card text-center py-8">
        <Target size={32} className="mx-auto text-cs-muted mb-3" />
        <p className="text-cs-muted">Sign in to place your prediction</p>
      </div>
    );
  }

  if (isClosed) {
    return (
      <div className="card">
        <div className="flex items-center gap-2 text-cs-muted text-sm">
          <AlertCircle size={16} />
          Predictions are closed for this match.
        </div>
        {existingBet && (
          <div className="mt-3 p-3 bg-cs-surface rounded-lg text-sm">
            <div className="text-cs-muted mb-1">Your prediction:</div>
            <div className="font-semibold text-cs-accent">{existingBet.predicted_winner}</div>
            {existingBet.predicted_score_a !== null && (
              <div className="text-cs-muted mt-0.5 font-mono">
                {existingBet.predicted_score_a} : {existingBet.predicted_score_b}
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  async function handleSubmit() {
    if (!winner) {
      setError('Please select a winner');
      return;
    }

    // Validate score
    const hasScore = scoreA !== '' && scoreB !== '';
    if ((scoreA !== '' || scoreB !== '') && !hasScore) {
      setError('Enter both score values or leave both empty');
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      await api.post('/api/bets', {
        match_id: match.id,
        predicted_winner: winner,
        predicted_score_a: hasScore ? parseInt(scoreA) : null,
        predicted_score_b: hasScore ? parseInt(scoreB) : null,
      });
      setSuccess('Prediction saved!');
      onBetPlaced?.();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card space-y-4">
      <h3 className="font-display text-xl tracking-widest text-cs-text">
        YOUR PREDICTION
      </h3>

      {/* Winner selection */}
      <div>
        <label className="text-xs text-cs-muted uppercase tracking-wider mb-2 block">Pick the winner</label>
        <div className="grid grid-cols-2 gap-3">
          {[match.team_a, match.team_b].map(team => (
            <button
              key={team}
              onClick={() => setWinner(team)}
              className={`py-3 px-4 rounded-xl border-2 font-semibold text-sm transition-all duration-200 ${
                winner === team
                  ? 'border-cs-accent bg-cs-accent/10 text-cs-accent shadow-glow-orange'
                  : 'border-cs-border bg-cs-surface text-cs-muted hover:border-cs-accent/40 hover:text-cs-text'
              }`}
            >
              {team}
            </button>
          ))}
        </div>
      </div>

      {/* Exact score */}
      <div>
        <label className="text-xs text-cs-muted uppercase tracking-wider mb-2 block">
          Exact score <span className="text-cs-accent/60">(+3 pts)</span> — optional
        </label>
        <div className="flex items-center gap-3">
          <input
            type="number"
            min="0"
            max="99"
            value={scoreA}
            onChange={e => setScoreA(e.target.value)}
            placeholder="0"
            className="input text-center font-mono text-lg"
          />
          <span className="text-cs-muted font-display text-2xl">:</span>
          <input
            type="number"
            min="0"
            max="99"
            value={scoreB}
            onChange={e => setScoreB(e.target.value)}
            placeholder="0"
            className="input text-center font-mono text-lg"
          />
        </div>
        <p className="text-xs text-cs-muted mt-1.5">
          {match.team_a} score : {match.team_b} score
        </p>
      </div>

      {/* Points legend */}
      <div className="bg-cs-surface rounded-lg p-3 grid grid-cols-3 gap-2 text-center">
        <div>
          <div className="font-mono font-bold text-cs-accent">+1</div>
          <div className="text-xs text-cs-muted">Correct winner</div>
        </div>
        <div>
          <div className="font-mono font-bold text-cs-green">+3</div>
          <div className="text-xs text-cs-muted">Exact score</div>
        </div>
        <div>
          <div className="font-mono font-bold text-cs-accent2">+2</div>
          <div className="text-xs text-cs-muted">Bonus answer</div>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-cs-red text-sm bg-cs-red/10 border border-cs-red/20 rounded-lg px-3 py-2">
          <AlertCircle size={14} />
          {error}
        </div>
      )}

      {success && (
        <div className="flex items-center gap-2 text-cs-green text-sm bg-cs-green/10 border border-cs-green/20 rounded-lg px-3 py-2">
          <CheckCircle2 size={14} />
          {success}
        </div>
      )}

      <button
        onClick={handleSubmit}
        disabled={loading}
        className="btn-primary w-full flex items-center justify-center gap-2"
      >
        {loading ? <Loader2 size={16} className="animate-spin" /> : <Target size={16} />}
        {existingBet ? 'Update Prediction' : 'Place Prediction'}
      </button>
    </div>
  );
}
