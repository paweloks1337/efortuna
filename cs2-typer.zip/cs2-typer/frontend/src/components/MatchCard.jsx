import { useNavigate } from 'react-router-dom';
import { format, formatDistanceToNow, isPast } from 'date-fns';
import { Clock, ChevronRight, CheckCircle2, Swords } from 'lucide-react';

const STATUS_CONFIG = {
  upcoming: { label: 'Upcoming', className: 'badge-upcoming' },
  live: { label: '● LIVE', className: 'badge-live' },
  finished: { label: 'Finished', className: 'badge-finished' },
};

export default function MatchCard({ match, userBet }) {
  const navigate = useNavigate();
  const startTime = new Date(match.start_time);
  const started = isPast(startTime);

  const status = STATUS_CONFIG[match.status] || STATUS_CONFIG.upcoming;

  return (
    <div
      className="card-hover group relative overflow-hidden"
      onClick={() => navigate(`/matches/${match.id}`)}
    >
      {/* Decorative gradient line */}
      <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cs-accent/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      <div className="flex items-center justify-between mb-4">
        <span className={status.className}>{status.label}</span>
        <div className="flex items-center gap-1.5 text-cs-muted text-xs">
          <Clock size={12} />
          {match.status === 'upcoming' && !started
            ? formatDistanceToNow(startTime, { addSuffix: true })
            : format(startTime, 'MMM d, HH:mm')}
        </div>
      </div>

      {/* Teams */}
      <div className="flex items-center gap-3">
        {/* Team A */}
        <div className="flex-1 text-center">
          <div className="w-12 h-12 rounded-xl bg-cs-surface border border-cs-border mx-auto mb-2 flex items-center justify-center">
            <span className="font-display text-lg text-cs-accent2">
              {match.team_a.slice(0, 2).toUpperCase()}
            </span>
          </div>
          <div className="font-semibold text-sm text-cs-text truncate">{match.team_a}</div>
        </div>

        {/* VS / Score */}
        <div className="flex flex-col items-center gap-1 min-w-[60px]">
          {match.status === 'finished' && match.score_a !== null ? (
            <div className="font-display text-2xl text-cs-text tracking-widest">
              {match.score_a}<span className="text-cs-muted mx-0.5">:</span>{match.score_b}
            </div>
          ) : (
            <div className="flex items-center gap-1 text-cs-muted">
              <Swords size={16} />
            </div>
          )}
          <span className="text-cs-muted text-xs">VS</span>
        </div>

        {/* Team B */}
        <div className="flex-1 text-center">
          <div className="w-12 h-12 rounded-xl bg-cs-surface border border-cs-border mx-auto mb-2 flex items-center justify-center">
            <span className="font-display text-lg text-cs-accent">
              {match.team_b.slice(0, 2).toUpperCase()}
            </span>
          </div>
          <div className="font-semibold text-sm text-cs-text truncate">{match.team_b}</div>
        </div>
      </div>

      {/* User bet indicator */}
      <div className="mt-4 pt-4 border-t border-cs-border flex items-center justify-between">
        {userBet ? (
          <div className="flex items-center gap-2 text-xs text-cs-green">
            <CheckCircle2 size={13} />
            <span>Bet placed: <span className="font-semibold">{userBet.predicted_winner}</span>
              {userBet.predicted_score_a !== null && ` (${userBet.predicted_score_a}:${userBet.predicted_score_b})`}
            </span>
          </div>
        ) : (
          <span className="text-xs text-cs-muted">
            {match.status === 'upcoming' && !started ? 'Click to predict' : 'No prediction'}
          </span>
        )}
        <ChevronRight size={16} className="text-cs-muted group-hover:text-cs-accent transition-colors" />
      </div>

      {/* Points badge if settled */}
      {userBet?.points_awarded !== null && userBet?.points_awarded !== undefined && (
        <div className={`absolute top-3 right-3 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold font-mono ${
          userBet.points_awarded > 0 ? 'bg-cs-green/20 text-cs-green border border-cs-green/30' : 'bg-cs-muted/10 text-cs-muted'
        }`}>
          +{userBet.points_awarded}
        </div>
      )}
    </div>
  );
}
