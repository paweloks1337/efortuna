import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Crosshair, Trophy, User, ShieldCheck, LogOut, LogIn, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Layout() {
  const { user, profile, isAdmin, signInWithGoogle, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { to: '/', label: 'Matches', icon: Crosshair },
    { to: '/ranking', label: 'Ranking', icon: Trophy },
    ...(user ? [{ to: '/profile', label: 'My Bets', icon: User }] : []),
    ...(isAdmin ? [{ to: '/admin', label: 'Admin', icon: ShieldCheck }] : []),
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-cs-bg/90 backdrop-blur-md border-b border-cs-border">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          {/* Logo */}
          <button onClick={() => navigate('/')} className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-cs-accent rounded-lg flex items-center justify-center shadow-glow-orange group-hover:scale-105 transition-transform">
              <Crosshair size={18} className="text-white" />
            </div>
            <span className="font-display text-2xl tracking-widest text-white glow-text-orange">
              CS2<span className="text-cs-accent">TYPER</span>
            </span>
          </button>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                    isActive
                      ? 'bg-cs-accent/10 text-cs-accent border border-cs-accent/20'
                      : 'text-cs-muted hover:text-cs-text hover:bg-cs-surface'
                  }`
                }
              >
                <Icon size={15} />
                {label}
              </NavLink>
            ))}
          </div>

          {/* Auth */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  {profile?.avatar ? (
                    <img src={profile.avatar} alt="" className="w-8 h-8 rounded-full border border-cs-border" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-cs-accent/20 border border-cs-accent/30 flex items-center justify-center text-cs-accent text-xs font-bold">
                      {profile?.username?.[0]?.toUpperCase() || '?'}
                    </div>
                  )}
                  <div className="text-right">
                    <div className="text-sm font-semibold text-cs-text leading-none">{profile?.username}</div>
                    <div className="text-xs text-cs-accent font-mono leading-none mt-0.5">{profile?.points ?? 0} pts</div>
                  </div>
                </div>
                <button onClick={signOut} className="btn-ghost text-sm flex items-center gap-1.5">
                  <LogOut size={14} />
                  Out
                </button>
              </div>
            ) : (
              <button onClick={signInWithGoogle} className="btn-primary flex items-center gap-2 text-sm">
                <LogIn size={15} />
                Sign In
              </button>
            )}
          </div>

          {/* Mobile menu btn */}
          <button className="md:hidden text-cs-muted hover:text-cs-text" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <div className="md:hidden border-t border-cs-border bg-cs-bg p-4 space-y-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                    isActive ? 'bg-cs-accent/10 text-cs-accent' : 'text-cs-muted hover:text-cs-text'
                  }`
                }
              >
                <Icon size={16} />
                {label}
              </NavLink>
            ))}
            <div className="pt-3 border-t border-cs-border">
              {user ? (
                <button onClick={() => { signOut(); setMobileOpen(false); }}
                  className="w-full flex items-center gap-2 px-4 py-3 text-sm text-cs-muted hover:text-cs-red">
                  <LogOut size={15} /> Sign Out
                </button>
              ) : (
                <button onClick={() => { signInWithGoogle(); setMobileOpen(false); }}
                  className="w-full btn-primary text-sm flex items-center justify-center gap-2">
                  <LogIn size={15} /> Sign In with Google
                </button>
              )}
            </div>
          </div>
        )}
      </nav>

      {/* Page content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t border-cs-border py-6 text-center text-cs-muted text-sm">
        <span className="font-display tracking-widest text-cs-accent/60">CS2TYPER</span>
        <span className="ml-2">— Predict. Compete. Dominate.</span>
      </footer>
    </div>
  );
}
