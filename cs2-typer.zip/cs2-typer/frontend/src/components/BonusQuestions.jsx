import { useState } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { HelpCircle, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { isPast } from 'date-fns';

export default function BonusQuestions({ match, questions, userAnswers = [], onAnswered }) {
  const { user } = useAuth();
  const isClosed = isPast(new Date(match.start_time)) || match.status !== 'upcoming';

  if (!questions || questions.length === 0) return null;

  return (
    <div className="card space-y-4">
      <h3 className="font-display text-xl tracking-widest text-cs-text flex items-center gap-2">
        <HelpCircle size={18} className="text-cs-accent2" />
        BONUS QUESTIONS
      </h3>
      <div className="space-y-4">
        {questions.map(q => {
          const existing = userAnswers.find(a => a.question_id === q.id);
          return (
            <QuestionItem
              key={q.id}
              question={q}
              existingAnswer={existing}
              isClosed={isClosed}
              isLoggedIn={!!user}
              onAnswered={onAnswered}
            />
          );
        })}
      </div>
    </div>
  );
}

function QuestionItem({ question, existingAnswer, isClosed, isLoggedIn, onAnswered }) {
  const [answer, setAnswer] = useState(existingAnswer?.answer || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  async function handleSubmit() {
    if (!answer.trim()) {
      setError('Please enter an answer');
      return;
    }
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      await api.post('/api/bonus/answer', {
        question_id: question.id,
        answer: answer.trim()
      });
      setSuccess('Answer saved!');
      onAnswered?.();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-cs-surface border border-cs-border rounded-xl p-4 space-y-3">
      <p className="text-sm font-medium text-cs-text">{question.question}</p>

      {/* Show correct answer after match settled */}
      {question.correct_answer && isClosed && (
        <div className="text-xs text-cs-accent2 bg-cs-accent2/5 border border-cs-accent2/20 rounded-lg px-3 py-2">
          Correct answer: <span className="font-semibold">{question.correct_answer}</span>
        </div>
      )}

      {existingAnswer?.points_awarded !== null && existingAnswer?.points_awarded !== undefined && (
        <div className={`text-xs font-semibold ${existingAnswer.points_awarded > 0 ? 'text-cs-green' : 'text-cs-muted'}`}>
          {existingAnswer.points_awarded > 0 ? `+${existingAnswer.points_awarded} points earned!` : 'Incorrect — 0 points'}
        </div>
      )}

      {!isClosed && isLoggedIn && (
        <div className="flex gap-2">
          <input
            value={answer}
            onChange={e => setAnswer(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSubmit()}
            placeholder="Your answer..."
            className="input text-sm flex-1"
          />
          <button onClick={handleSubmit} disabled={loading} className="btn-primary px-4 text-sm flex items-center gap-1.5">
            {loading ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
            Save
          </button>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-1.5 text-cs-red text-xs">
          <AlertCircle size={12} /> {error}
        </div>
      )}
      {success && (
        <div className="flex items-center gap-1.5 text-cs-green text-xs">
          <CheckCircle2 size={12} /> {success}
        </div>
      )}
    </div>
  );
}
