import { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import MatchCard from '../components/MatchCard';
import { Crosshair, Loader2, Swords } from 'lucide-react';

const TABS = ['all', 'upcoming', 'finished'];

export default function MatchesPage() {
  const { user } = useAuth();
  const [matches, setMatches] = useState([]);
  const [userBets, setUserBets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('all');

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const m = await api.get('/api/matches');
        setMatches(m);
        if (user) {
          const b = await api.get('/api/bets/my');
          setUserBets(b);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user]);

  const filtered = matches.filter(m => tab === 'all' || m.status === tab);

  const betMap = {};
  userBets.forEach(b => { betMap[b.match_id] = b; });

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Swords size={22} className="text-cs-accent" />
          <h1 className="section-title">Matches</h1>
        </div>
        <p className="text-cs-muted text-sm">Predict the outcome and climb the leaderboard</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold capitalize transition-all duration-200 ${
              tab === t
                ? 'bg-cs-accent text-white shadow-glow-orange'
                : 'bg-cs-surface border border-cs-border text-cs-muted hover:text-cs-text'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 size={28} className="animate-spin text-cs-accent" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="card text-center py-16">
          <Crosshair size={40} className="mx-auto text-cs-muted mb-3 opacity-40" />
          <p className="text-cs-muted">No {tab === 'all' ? '' : tab} matches yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(m => (
            <MatchCard key={m.id} match={m} userBet={betMap[m.id]} />
          ))}
        </div>
      )}
    </div>
  );
}
