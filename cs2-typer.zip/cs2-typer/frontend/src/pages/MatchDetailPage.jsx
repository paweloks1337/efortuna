import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import BetForm from '../components/BetForm';
import BonusQuestions from '../components/BonusQuestions';
import { format, formatDistanceToNow, isPast } from 'date-fns';
import {
  ArrowLeft, Clock, Swords, Trophy, Loader2, Shield
} from 'lucide-react';

const STATUS_CONFIG = {
  upcoming: { label: 'Upcoming', className: 'badge-upcoming' },
  live: { label: '● LIVE', className: 'badge-live' },
  finished: { label: 'Finished', className: 'badge-finished' },
};

export default function MatchDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [match, setMatch] = useState(null);
  const [userBet, setUserBet] = useState(null);
  const [userAnswers, setUserAnswers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const m = await api.get(`/api/matches/${id}`);
      setMatch(m);
      if (user) {
        const bets = await api.get(`/api/bets/match/${id}`);
        setUserBet(bets[0] || null);
        const answers = await api.get('/api/bonus/my');
        setUserAnswers(answers);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [id, user]);

  useEffect(() => { load(); }, [load]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-32">
        <Loader2 size={32} className="animate-spin text-cs-accent" />
      </div>
    );
  }

  if (!match) {
    return (
      <div className="card text-center py-16">
        <p className="text-cs-muted">Match not found</p>
        <button onClick={() => navigate('/')} className="btn-ghost mt-4">Go back</button>
      </div>
    );
  }

  const startTime = new Date(match.start_time);
  const started = isPast(startTime);
  const status = STATUS_CONFIG[match.status] || STATUS_CONFIG.upcoming;
  const winner = match.result;

  return (
    <div className="animate-fade-in max-w-3xl mx-auto">
      {/* Back */}
      <button
        onClick={() => navigate('/')}
        className="flex items-center gap-2 text-cs-muted hover:text-cs-text text-sm mb-6 transition-colors"
      >
        <ArrowLeft size={16} /> Back to Matches
      </button>

      {/* Match header card */}
      <div className="card mb-5 relative overflow-hidden">
        {/* Background accent */}
        <div className="absolute inset-0 bg-gradient-to-br from-cs-accent/5 via-transparent to-cs-accent2/5 pointer-events-none" />

        <div className="relative">
          {/* Status + time */}
          <div className="flex items-center justify-between mb-6">
            <span className={status.className}>{status.label}</span>
            <div className="flex items-center gap-2 text-cs-muted text-sm">
              <Clock size={14} />
              {match.status === 'upcoming' && !started
                ? formatDistanceToNow(startTime, { addSuffix: true })
                : format(startTime, 'MMM d, yyyy · HH:mm')}
            </div>
          </div>

          {/* Teams vs score */}
          <div className="flex items-center justify-between gap-4">
            {/* Team A */}
            <TeamBlock
              name={match.team_a}
              isWinner={winner === match.team_a}
              color="cyan"
              userPick={userBet?.predicted_winner === match.team_a}
            />

            {/* Center */}
            <div className="flex flex-col items-center gap-2 min-w-[100px]">
              {match.status === 'finished' && match.score_a !== null ? (
                <div className="font-display text-5xl text-white tracking-widest">
                  {match.score_a}
                  <span className="text-cs-muted mx-1 text-3xl">:</span>
                  {match.score_b}
                </div>
              ) : (
                <div className="flex items-center gap-2 text-cs-muted">
                  <Swords size={24} />
                </div>
              )}
              <span className="text-xs text-cs-muted uppercase tracking-widest">VS</span>
            </div>

            {/* Team B */}
            <TeamBlock
              name={match.team_b}
              isWinner={winner === match.team_b}
              color="orange"
              userPick={userBet?.predicted_winner === match.team_b}
            />
          </div>

          {/* User bet result */}
          {userBet?.points_awarded !== null && userBet?.points_awarded !== undefined && (
            <div className={`mt-6 p-3 rounded-xl text-center text-sm font-semibold ${
              userBet.points_awarded > 0
                ? 'bg-cs-green/10 border border-cs-green/20 text-cs-green'
                : 'bg-cs-muted/10 border border-cs-muted/20 text-cs-muted'
            }`}>
              {userBet.points_awarded > 0
                ? `🎯 You earned +${userBet.points_awarded} points!`
                : '😔 No points this time'}
            </div>
          )}
        </div>
      </div>

      {/* Bet form + bonus */}
      <div className="space-y-4">
        <BetForm
          match={match}
          existingBet={userBet}
          onBetPlaced={load}
        />
        <BonusQuestions
          match={match}
          questions={match.bonus_questions || []}
          userAnswers={userAnswers}
          onAnswered={load}
        />
      </div>
    </div>
  );
}

function TeamBlock({ name, isWinner, color, userPick }) {
  const colors = {
    cyan: { border: 'border-cs-accent2/40', bg: 'bg-cs-accent2/10', text: 'text-cs-accent2', abbr: 'text-cs-accent2' },
    orange: { border: 'border-cs-accent/40', bg: 'bg-cs-accent/10', text: 'text-cs-accent', abbr: 'text-cs-accent' },
  };
  const c = colors[color];

  return (
    <div className={`flex-1 text-center ${isWinner ? 'scale-105' : ''} transition-transform`}>
      <div className={`w-16 h-16 rounded-2xl border-2 mx-auto mb-3 flex items-center justify-center ${
        isWinner ? `${c.border} ${c.bg}` : 'border-cs-border bg-cs-surface'
      }`}>
        {isWinner
          ? <Trophy size={24} className={c.text} />
          : <Shield size={22} className="text-cs-muted" />}
      </div>
      <div className="font-bold text-cs-text text-sm truncate px-2">{name}</div>
      {isWinner && <div className={`text-xs font-semibold mt-1 ${c.text}`}>WINNER</div>}
      {userPick && !isWinner && (
        <div className="text-xs text-cs-muted mt-1">Your pick</div>
      )}
      {userPick && isWinner && (
        <div className="text-xs text-cs-green mt-1 font-semibold">✓ Your pick</div>
      )}
    </div>
  );
}
