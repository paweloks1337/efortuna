import { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { format } from 'date-fns';
import { User, Target, CheckCircle2, XCircle, Clock, Loader2, Edit2, Save } from 'lucide-react';

export default function ProfilePage() {
  const { profile, refreshProfile } = useAuth();
  const [bets, setBets] = useState([]);
  const [answers, setAnswers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState('');
  const [savingName, setSavingName] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const [b, a] = await Promise.all([
          api.get('/api/bets/my'),
          api.get('/api/bonus/my'),
        ]);
        setBets(b);
        setAnswers(a);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  async function handleSaveName() {
    if (!newName.trim()) return;
    setSavingName(true);
    try {
      await api.patch('/api/users/me', { username: newName.trim() });
      await refreshProfile();
      setEditingName(false);
    } catch (e) {
      console.error(e);
    } finally {
      setSavingName(false);
    }
  }

  const totalPoints = profile?.points ?? 0;
  const exactCount = bets.filter(b => b.exact_score_correct).length;
  const winnerCount = bets.filter(b => b.winner_correct).length;
  const bonusCorrect = answers.filter(a => a.points_awarded > 0).length;

  return (
    <div className="animate-fade-in max-w-2xl mx-auto">
      {/* Profile header */}
      <div className="card mb-5 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-cs-accent/5 to-transparent pointer-events-none" />
        <div className="relative flex items-start gap-5">
          {profile?.avatar ? (
            <img src={profile.avatar} alt="" className="w-16 h-16 rounded-2xl border-2 border-cs-border flex-shrink-0" />
          ) : (
            <div className="w-16 h-16 rounded-2xl bg-cs-accent/10 border-2 border-cs-accent/20 flex items-center justify-center flex-shrink-0">
              <User size={28} className="text-cs-accent" />
            </div>
          )}

          <div className="flex-1 min-w-0">
            {editingName ? (
              <div className="flex items-center gap-2 mb-1">
                <input
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') handleSaveName(); if (e.key === 'Escape') setEditingName(false); }}
                  className="input py-1 text-sm flex-1"
                  placeholder="New username"
                  autoFocus
                />
                <button onClick={handleSaveName} disabled={savingName} className="btn-primary py-1 px-3 text-sm flex items-center gap-1">
                  {savingName ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 mb-1">
                <h2 className="font-bold text-xl text-cs-text">{profile?.username}</h2>
                <button
                  onClick={() => { setNewName(profile?.username || ''); setEditingName(true); }}
                  className="text-cs-muted hover:text-cs-text transition-colors"
                >
                  <Edit2 size={14} />
                </button>
              </div>
            )}
            <p className="text-cs-muted text-sm">{profile?.email}</p>
          </div>

          <div className="text-right flex-shrink-0">
            <div className="font-display text-4xl text-cs-accent glow-text-orange">{totalPoints}</div>
            <div className="text-xs text-cs-muted uppercase tracking-wider">points</div>
          </div>
        </div>

        {/* Stats row */}
        <div className="mt-5 grid grid-cols-3 gap-3">
          <StatBox label="Bets placed" value={bets.length} />
          <StatBox label="Exact scores" value={exactCount} color="green" />
          <StatBox label="Bonus correct" value={bonusCorrect} color="cyan" />
        </div>
      </div>

      {/* Bets history */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 size={24} className="animate-spin text-cs-accent" />
        </div>
      ) : (
        <div className="space-y-4">
          <h3 className="font-display text-xl tracking-widest text-cs-text flex items-center gap-2">
            <Target size={18} className="text-cs-accent" />
            PREDICTION HISTORY
          </h3>

          {bets.length === 0 ? (
            <div className="card text-center py-10">
              <Target size={32} className="mx-auto text-cs-muted mb-3 opacity-40" />
              <p className="text-cs-muted text-sm">No predictions yet — go pick a match!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {bets.map(bet => (
                <BetHistoryItem key={bet.id} bet={bet} />
              ))}
            </div>
          )}

          {/* Bonus answers */}
          {answers.length > 0 && (
            <>
              <h3 className="font-display text-xl tracking-widest text-cs-text flex items-center gap-2 mt-6">
                <CheckCircle2 size={18} className="text-cs-accent2" />
                BONUS ANSWERS
              </h3>
              <div className="space-y-3">
                {answers.map(ans => (
                  <BonusHistoryItem key={ans.id} answer={ans} />
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function StatBox({ label, value, color }) {
  const colorMap = {
    green: 'text-cs-green',
    cyan: 'text-cs-accent2',
  };
  return (
    <div className="bg-cs-surface rounded-xl p-3 text-center">
      <div className={`font-mono font-bold text-2xl ${colorMap[color] || 'text-cs-text'}`}>{value}</div>
      <div className="text-xs text-cs-muted mt-0.5">{label}</div>
    </div>
  );
}

function BetHistoryItem({ bet }) {
  const match = bet.matches;
  const settled = bet.points_awarded !== null && bet.points_awarded !== undefined;

  return (
    <div className="card py-3 px-4 flex items-center gap-4">
      {/* Status icon */}
      <div className="flex-shrink-0">
        {!settled ? (
          <Clock size={18} className="text-cs-muted" />
        ) : bet.points_awarded > 0 ? (
          <CheckCircle2 size={18} className="text-cs-green" />
        ) : (
          <XCircle size={18} className="text-cs-red" />
        )}
      </div>

      {/* Match info */}
      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold text-cs-text truncate">
          {match?.team_a} vs {match?.team_b}
        </div>
        <div className="text-xs text-cs-muted mt-0.5">
          Predicted: <span className="text-cs-accent">{bet.predicted_winner}</span>
          {bet.predicted_score_a !== null && bet.predicted_score_a !== undefined && (
            <span className="ml-2 font-mono">{bet.predicted_score_a}:{bet.predicted_score_b}</span>
          )}
        </div>
        {match?.start_time && (
          <div className="text-xs text-cs-muted/60 mt-0.5">
            {format(new Date(match.start_time), 'MMM d, yyyy · HH:mm')}
          </div>
        )}
      </div>

      {/* Points */}
      <div className="flex-shrink-0 text-right">
        {settled ? (
          <span className={`font-mono font-bold ${bet.points_awarded > 0 ? 'text-cs-green' : 'text-cs-muted'}`}>
            +{bet.points_awarded}
          </span>
        ) : (
          <span className="text-xs text-cs-muted badge-upcoming px-2 py-0.5 rounded-full">
            {match?.status === 'upcoming' ? 'Pending' : 'Awaiting'}
          </span>
        )}
        {bet.exact_score_correct && (
          <div className="text-xs text-cs-green mt-0.5">Exact score!</div>
        )}
      </div>
    </div>
  );
}

function BonusHistoryItem({ answer }) {
  const q = answer.bonus_questions;
  const settled = answer.points_awarded !== null && answer.points_awarded !== undefined;

  return (
    <div className="card py-3 px-4 flex items-center gap-4">
      <div className="flex-shrink-0">
        {!settled ? (
          <Clock size={18} className="text-cs-muted" />
        ) : answer.points_awarded > 0 ? (
          <CheckCircle2 size={18} className="text-cs-green" />
        ) : (
          <XCircle size={18} className="text-cs-red" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs text-cs-muted">
          {q?.matches?.team_a} vs {q?.matches?.team_b}
        </div>
        <div className="text-sm text-cs-text font-medium truncate">{q?.question}</div>
        <div className="text-xs text-cs-muted mt-0.5">
          Your answer: <span className="text-cs-accent2">{answer.answer}</span>
        </div>
      </div>
      <div className="flex-shrink-0">
        {settled ? (
          <span className={`font-mono font-bold ${answer.points_awarded > 0 ? 'text-cs-green' : 'text-cs-muted'}`}>
            +{answer.points_awarded}
          </span>
        ) : (
          <span className="text-xs text-cs-muted">Pending</span>
        )}
      </div>
    </div>
  );
}
