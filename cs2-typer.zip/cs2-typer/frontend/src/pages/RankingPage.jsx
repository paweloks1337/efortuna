import { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Trophy, Medal, Loader2, Crown } from 'lucide-react';

function RankIcon({ rank }) {
  if (rank === 1) return <Crown size={16} className="text-yellow-400" />;
  if (rank === 2) return <Medal size={16} className="text-slate-300" />;
  if (rank === 3) return <Medal size={16} className="text-amber-600" />;
  return <span className="text-cs-muted font-mono text-sm">#{rank}</span>;
}

export default function RankingPage() {
  const { profile } = useAuth();
  const [ranking, setRanking] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/api/ranking')
      .then(setRanking)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const top3 = ranking.slice(0, 3);
  const rest = ranking.slice(3);
  const myEntry = profile ? ranking.find(r => r.id === profile.id) : null;

  return (
    <div className="animate-fade-in max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Trophy size={22} className="text-cs-yellow" />
          <h1 className="section-title">Leaderboard</h1>
        </div>
        <p className="text-cs-muted text-sm">Global rankings — updated after each settlement</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 size={28} className="animate-spin text-cs-accent" />
        </div>
      ) : ranking.length === 0 ? (
        <div className="card text-center py-16">
          <Trophy size={40} className="mx-auto text-cs-muted mb-3 opacity-40" />
          <p className="text-cs-muted">No players yet — be the first to predict!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Podium top 3 */}
          {top3.length >= 3 && (
            <div className="grid grid-cols-3 gap-3 mb-6">
              {[top3[1], top3[0], top3[2]].map((p, podiumIdx) => {
                if (!p) return <div key={podiumIdx} />;
                const heights = ['h-28', 'h-36', 'h-24'];
                const isMe = p.id === profile?.id;
                return (
                  <div key={p.id} className={`card flex flex-col items-center justify-end ${heights[podiumIdx]} py-3 relative ${
                    podiumIdx === 1 ? 'border-cs-yellow/40 shadow-[0_0_20px_rgba(234,179,8,0.15)]' : ''
                  } ${isMe ? 'border-cs-accent/40' : ''}`}>
                    <div className="absolute -top-3">
                      <RankIcon rank={p.rank} />
                    </div>
                    {p.avatar ? (
                      <img src={p.avatar} alt="" className="w-10 h-10 rounded-full border-2 border-cs-border mb-2" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-cs-surface border-2 border-cs-border flex items-center justify-center text-sm font-bold text-cs-accent mb-2">
                        {p.username?.[0]?.toUpperCase()}
                      </div>
                    )}
                    <div className="text-xs font-semibold text-cs-text truncate w-full text-center px-1">{p.username}</div>
                    <div className="font-mono font-bold text-cs-accent text-sm">{p.points} pts</div>
                  </div>
                );
              })}
            </div>
          )}

          {/* My rank sticky banner */}
          {myEntry && myEntry.rank > 3 && (
            <div className="card border-cs-accent/40 bg-cs-accent/5 flex items-center gap-4 py-3">
              <div className="flex items-center justify-center w-8 h-8">
                <RankIcon rank={myEntry.rank} />
              </div>
              <div className="flex items-center gap-3 flex-1">
                {myEntry.avatar ? (
                  <img src={myEntry.avatar} alt="" className="w-8 h-8 rounded-full border border-cs-border" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-cs-accent/20 border border-cs-accent/30 flex items-center justify-center text-xs font-bold text-cs-accent">
                    {myEntry.username?.[0]?.toUpperCase()}
                  </div>
                )}
                <div>
                  <div className="font-semibold text-sm text-cs-accent">{myEntry.username} (You)</div>
                  <div className="text-xs text-cs-muted">{myEntry.exact_score_count} exact scores</div>
                </div>
              </div>
              <div className="font-mono font-bold text-cs-accent">{myEntry.points} pts</div>
            </div>
          )}

          {/* Full list */}
          <div className="card p-0 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-cs-border">
                  <th className="text-left px-4 py-3 text-cs-muted text-xs uppercase tracking-wider w-12">#</th>
                  <th className="text-left px-4 py-3 text-cs-muted text-xs uppercase tracking-wider">Player</th>
                  <th className="text-right px-4 py-3 text-cs-muted text-xs uppercase tracking-wider">Exact</th>
                  <th className="text-right px-4 py-3 text-cs-muted text-xs uppercase tracking-wider">Points</th>
                </tr>
              </thead>
              <tbody>
                {ranking.map((player, i) => {
                  const isMe = player.id === profile?.id;
                  const isTop = player.rank <= 3;
                  return (
                    <tr
                      key={player.id}
                      className={`border-b border-cs-border/50 last:border-0 transition-colors ${
                        isMe ? 'bg-cs-accent/5' : 'hover:bg-cs-surface/50'
                      }`}
                    >
                      <td className="px-4 py-3 w-12">
                        <div className="flex items-center justify-center">
                          <RankIcon rank={player.rank} />
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          {player.avatar ? (
                            <img src={player.avatar} alt="" className="w-8 h-8 rounded-full border border-cs-border flex-shrink-0" />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-cs-surface border border-cs-border flex items-center justify-center text-xs font-bold text-cs-muted flex-shrink-0">
                              {player.username?.[0]?.toUpperCase()}
                            </div>
                          )}
                          <span className={`font-semibold truncate ${isMe ? 'text-cs-accent' : 'text-cs-text'}`}>
                            {player.username}
                            {isMe && <span className="text-xs ml-1 opacity-60">(you)</span>}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className="font-mono text-cs-muted text-xs">{player.exact_score_count}</span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className={`font-mono font-bold ${isTop ? 'text-cs-yellow' : isMe ? 'text-cs-accent' : 'text-cs-text'}`}>
                          {player.points}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Points legend */}
          <div className="card bg-cs-surface/50">
            <h4 className="text-xs text-cs-muted uppercase tracking-wider mb-3 font-semibold">Scoring system</h4>
            <div className="grid grid-cols-3 gap-3 text-center text-xs">
              <div className="bg-cs-card rounded-lg p-3">
                <div className="font-mono font-bold text-cs-accent text-lg">+1</div>
                <div className="text-cs-muted mt-0.5">Correct winner</div>
              </div>
              <div className="bg-cs-card rounded-lg p-3">
                <div className="font-mono font-bold text-cs-green text-lg">+3</div>
                <div className="text-cs-muted mt-0.5">Exact score</div>
              </div>
              <div className="bg-cs-card rounded-lg p-3">
                <div className="font-mono font-bold text-cs-accent2 text-lg">+2</div>
                <div className="text-cs-muted mt-0.5">Bonus answer</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
