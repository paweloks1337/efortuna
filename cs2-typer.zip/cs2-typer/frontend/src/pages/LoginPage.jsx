import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Crosshair, LogIn, Swords, Trophy, Target } from 'lucide-react';

export default function LoginPage() {
  const { user, signInWithGoogle } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) navigate('/');
  }, [user]);

  return (
    <div className="min-h-screen bg-cs-bg flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-grid-pattern opacity-50" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-cs-accent/5 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] rounded-full bg-cs-accent2/5 blur-[100px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-cs-accent/10 border border-cs-accent/30 rounded-2xl mb-5 shadow-glow-orange">
            <Crosshair size={32} className="text-cs-accent" />
          </div>
          <h1 className="font-display text-5xl tracking-widest text-white glow-text-orange mb-2">
            CS2<span className="text-cs-accent">TYPER</span>
          </h1>
          <p className="text-cs-muted">Predict. Compete. Dominate.</p>
        </div>

        {/* Feature pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {[
            { icon: Swords, text: 'Live Matches' },
            { icon: Trophy, text: 'Leaderboard' },
            { icon: Target, text: 'Predictions' },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-1.5 px-3 py-1.5 bg-cs-surface border border-cs-border rounded-full text-xs text-cs-muted">
              <Icon size={12} className="text-cs-accent" />
              {text}
            </div>
          ))}
        </div>

        {/* Card */}
        <div className="card border-cs-accent/20 text-center">
          <h2 className="font-semibold text-lg text-cs-text mb-2">Join the competition</h2>
          <p className="text-cs-muted text-sm mb-6">
            Sign in to predict CS2 match outcomes, earn points, and climb the global leaderboard.
          </p>

          <button
            onClick={signInWithGoogle}
            className="w-full flex items-center justify-center gap-3 bg-white hover:bg-gray-100 text-gray-900 font-semibold py-3 px-6 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <svg width="18" height="18" viewBox="0 0 18 18">
              <path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"/>
              <path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z"/>
              <path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/>
              <path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"/>
            </svg>
            Continue with Google
          </button>

          <p className="text-xs text-cs-muted mt-4">
            By signing in you agree to our terms of service.
          </p>
        </div>
      </div>
    </div>
  );
}
