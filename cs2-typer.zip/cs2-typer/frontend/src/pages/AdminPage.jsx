import { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { format } from 'date-fns';
import {
  ShieldCheck, Plus, Settings, Loader2, CheckCircle2, AlertCircle,
  Trophy, HelpCircle, Swords, Users, Zap, X
} from 'lucide-react';

export default function AdminPage() {
  const [tab, setTab] = useState('matches');
  const [matches, setMatches] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  async function loadData() {
    setLoading(true);
    try {
      const [m, s] = await Promise.all([
        api.get('/api/admin/matches'),
        api.get('/api/admin/stats'),
      ]);
      setMatches(m);
      setStats(s);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadData(); }, []);

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-cs-accent/10 border border-cs-accent/20 flex items-center justify-center">
          <ShieldCheck size={20} className="text-cs-accent" />
        </div>
        <div>
          <h1 className="section-title">Admin Panel</h1>
          <p className="text-cs-muted text-xs">Manage matches, bonus questions, and settlements</p>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <StatCard icon={Users} label="Total Users" value={stats.users} color="cyan" />
          <StatCard icon={Swords} label="Matches" value={stats.matches} color="orange" />
          <StatCard icon={Trophy} label="Bets Placed" value={stats.bets} color="green" />
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {[
          { id: 'matches', label: 'Matches', icon: Swords },
          { id: 'add_match', label: 'Add Match', icon: Plus },
          { id: 'bonus', label: 'Bonus Questions', icon: HelpCircle },
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              tab === id ? 'bg-cs-accent text-white shadow-glow-orange' : 'bg-cs-surface border border-cs-border text-cs-muted hover:text-cs-text'
            }`}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 size={24} className="animate-spin text-cs-accent" />
        </div>
      ) : (
        <>
          {tab === 'matches' && <MatchList matches={matches} onUpdate={loadData} />}
          {tab === 'add_match' && <AddMatchForm onAdded={() => { loadData(); setTab('matches'); }} />}
          {tab === 'bonus' && <BonusManager matches={matches} onUpdate={loadData} />}
        </>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  const colors = {
    cyan: 'text-cs-accent2 bg-cs-accent2/10 border-cs-accent2/20',
    orange: 'text-cs-accent bg-cs-accent/10 border-cs-accent/20',
    green: 'text-cs-green bg-cs-green/10 border-cs-green/20',
  };
  return (
    <div className="card flex items-center gap-4">
      <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 ${colors[color]}`}>
        <Icon size={18} className={colors[color].split(' ')[0]} />
      </div>
      <div>
        <div className="font-mono font-bold text-2xl text-cs-text">{value ?? '—'}</div>
        <div className="text-xs text-cs-muted">{label}</div>
      </div>
    </div>
  );
}

function MatchList({ matches, onUpdate }) {
  return (
    <div className="space-y-3">
      {matches.length === 0 && (
        <div className="card text-center py-10 text-cs-muted">No matches yet.</div>
      )}
      {matches.map(m => (
        <MatchAdminCard key={m.id} match={m} onUpdate={onUpdate} />
      ))}
    </div>
  );
}

function MatchAdminCard({ match, onUpdate }) {
  const [result, setResult] = useState(match.result || '');
  const [scoreA, setScoreA] = useState(match.score_a ?? '');
  const [scoreB, setScoreB] = useState(match.score_b ?? '');
  const [status, setStatus] = useState(match.status || 'upcoming');
  const [saving, setSaving] = useState(false);
  const [settling, setSettling] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  async function handleSave() {
    setSaving(true);
    setMsg(''); setError('');
    try {
      await api.patch(`/api/admin/matches/${match.id}`, {
        result: result || undefined,
        score_a: scoreA !== '' ? parseInt(scoreA) : undefined,
        score_b: scoreB !== '' ? parseInt(scoreB) : undefined,
        status,
      });
      setMsg('Saved!');
      onUpdate();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleSettle() {
    if (!window.confirm(`Settle "${match.team_a} vs ${match.team_b}"? This calculates and awards all points.`)) return;
    setSettling(true);
    setMsg(''); setError('');
    try {
      const res = await api.post(`/api/admin/matches/${match.id}/settle`);
      setMsg(`Settled! ${res.bets_processed} bets, ${res.bonus_processed} bonus answers processed.`);
      onUpdate();
    } catch (e) {
      setError(e.message);
    } finally {
      setSettling(false);
    }
  }

  return (
    <div className={`card space-y-4 ${match.settled ? 'border-cs-green/20 opacity-75' : ''}`}>
      <div className="flex items-start justify-between">
        <div>
          <div className="font-bold text-cs-text">
            {match.team_a} <span className="text-cs-muted">vs</span> {match.team_b}
          </div>
          <div className="text-xs text-cs-muted mt-0.5">
            {format(new Date(match.start_time), 'MMM d, yyyy · HH:mm')}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {match.settled && (
            <span className="badge bg-cs-green/10 text-cs-green border-cs-green/20 text-xs">Settled</span>
          )}
          <span className={`badge ${
            match.status === 'upcoming' ? 'badge-upcoming' :
            match.status === 'live' ? 'badge-live' : 'badge-finished'
          }`}>{match.status}</span>
        </div>
      </div>

      {/* Edit fields */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div>
          <label className="text-xs text-cs-muted mb-1 block">Status</label>
          <select
            value={status}
            onChange={e => setStatus(e.target.value)}
            className="input text-sm py-2"
          >
            <option value="upcoming">Upcoming</option>
            <option value="live">Live</option>
            <option value="finished">Finished</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-cs-muted mb-1 block">Winner</label>
          <select
            value={result}
            onChange={e => setResult(e.target.value)}
            className="input text-sm py-2"
          >
            <option value="">— None —</option>
            <option value={match.team_a}>{match.team_a}</option>
            <option value={match.team_b}>{match.team_b}</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-cs-muted mb-1 block">{match.team_a} score</label>
          <input
            type="number" min="0" max="99"
            value={scoreA}
            onChange={e => setScoreA(e.target.value)}
            className="input text-sm py-2 font-mono"
            placeholder="0"
          />
        </div>
        <div>
          <label className="text-xs text-cs-muted mb-1 block">{match.team_b} score</label>
          <input
            type="number" min="0" max="99"
            value={scoreB}
            onChange={e => setScoreB(e.target.value)}
            className="input text-sm py-2 font-mono"
            placeholder="0"
          />
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button onClick={handleSave} disabled={saving} className="btn-secondary text-sm flex items-center gap-2 py-2">
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Settings size={14} />}
          Save changes
        </button>
        {!match.settled && (
          <button onClick={handleSettle} disabled={settling} className="btn-primary text-sm flex items-center gap-2 py-2">
            {settling ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
            Settle & Award Points
          </button>
        )}
      </div>

      {msg && (
        <div className="flex items-center gap-2 text-cs-green text-xs bg-cs-green/10 border border-cs-green/20 rounded-lg px-3 py-2">
          <CheckCircle2 size={12} /> {msg}
        </div>
      )}
      {error && (
        <div className="flex items-center gap-2 text-cs-red text-xs bg-cs-red/10 border border-cs-red/20 rounded-lg px-3 py-2">
          <AlertCircle size={12} /> {error}
        </div>
      )}
    </div>
  );
}

function AddMatchForm({ onAdded }) {
  const [teamA, setTeamA] = useState('');
  const [teamB, setTeamB] = useState('');
  const [startTime, setStartTime] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit() {
    if (!teamA.trim() || !teamB.trim() || !startTime) {
      setError('All fields are required');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await api.post('/api/admin/matches', {
        team_a: teamA.trim(),
        team_b: teamB.trim(),
        start_time: new Date(startTime).toISOString(),
      });
      setTeamA(''); setTeamB(''); setStartTime('');
      onAdded();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card max-w-lg space-y-4">
      <h3 className="font-display text-xl tracking-widest text-cs-text">ADD NEW MATCH</h3>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-cs-muted uppercase tracking-wider mb-1.5 block">Team A</label>
          <input value={teamA} onChange={e => setTeamA(e.target.value)} placeholder="e.g. NaVi" className="input" />
        </div>
        <div>
          <label className="text-xs text-cs-muted uppercase tracking-wider mb-1.5 block">Team B</label>
          <input value={teamB} onChange={e => setTeamB(e.target.value)} placeholder="e.g. Astralis" className="input" />
        </div>
      </div>

      <div>
        <label className="text-xs text-cs-muted uppercase tracking-wider mb-1.5 block">Start Time</label>
        <input
          type="datetime-local"
          value={startTime}
          onChange={e => setStartTime(e.target.value)}
          className="input"
        />
      </div>

      {error && (
        <div className="flex items-center gap-2 text-cs-red text-sm bg-cs-red/10 border border-cs-red/20 rounded-lg px-3 py-2">
          <AlertCircle size={14} /> {error}
        </div>
      )}

      <button onClick={handleSubmit} disabled={loading} className="btn-primary flex items-center gap-2">
        {loading ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
        Create Match
      </button>
    </div>
  );
}

function BonusManager({ matches, onUpdate }) {
  const [selectedMatch, setSelectedMatch] = useState('');
  const [question, setQuestion] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const allQuestions = matches.flatMap(m =>
    (m.bonus_questions || []).map(q => ({ ...q, match: m }))
  );

  async function handleSubmit() {
    if (!selectedMatch || !question.trim() || !correctAnswer.trim()) {
      setError('All fields required');
      return;
    }
    setLoading(true);
    setError(''); setSuccess('');
    try {
      await api.post('/api/admin/bonus', {
        match_id: selectedMatch,
        question: question.trim(),
        correct_answer: correctAnswer.trim(),
      });
      setQuestion(''); setCorrectAnswer('');
      setSuccess('Question added!');
      onUpdate();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-5">
      {/* Add form */}
      <div className="card space-y-4 max-w-lg">
        <h3 className="font-display text-xl tracking-widest text-cs-text">ADD BONUS QUESTION</h3>

        <div>
          <label className="text-xs text-cs-muted uppercase tracking-wider mb-1.5 block">Match</label>
          <select value={selectedMatch} onChange={e => setSelectedMatch(e.target.value)} className="input">
            <option value="">Select a match…</option>
            {matches.filter(m => m.status === 'upcoming').map(m => (
              <option key={m.id} value={m.id}>{m.team_a} vs {m.team_b}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-xs text-cs-muted uppercase tracking-wider mb-1.5 block">Question</label>
          <input
            value={question}
            onChange={e => setQuestion(e.target.value)}
            placeholder="e.g. How many rounds in map 1?"
            className="input"
          />
        </div>

        <div>
          <label className="text-xs text-cs-muted uppercase tracking-wider mb-1.5 block">Correct Answer</label>
          <input
            value={correctAnswer}
            onChange={e => setCorrectAnswer(e.target.value)}
            placeholder="e.g. 26"
            className="input"
          />
        </div>

        {error && (
          <div className="flex items-center gap-2 text-cs-red text-xs bg-cs-red/10 border border-cs-red/20 rounded-lg px-3 py-2">
            <AlertCircle size={12} /> {error}
          </div>
        )}
        {success && (
          <div className="flex items-center gap-2 text-cs-green text-xs bg-cs-green/10 border border-cs-green/20 rounded-lg px-3 py-2">
            <CheckCircle2 size={12} /> {success}
          </div>
        )}

        <button onClick={handleSubmit} disabled={loading} className="btn-primary flex items-center gap-2 text-sm">
          {loading ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
          Add Question
        </button>
      </div>

      {/* Existing questions */}
      {allQuestions.length > 0 && (
        <div>
          <h4 className="font-display text-lg tracking-widest text-cs-muted mb-3">ALL BONUS QUESTIONS</h4>
          <div className="space-y-2">
            {allQuestions.map(q => (
              <div key={q.id} className="card py-3 px-4 flex items-start gap-3">
                <HelpCircle size={16} className="text-cs-accent2 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-cs-muted mb-0.5">{q.match.team_a} vs {q.match.team_b}</div>
                  <div className="text-sm text-cs-text font-medium">{q.question}</div>
                  <div className="text-xs text-cs-accent2 mt-0.5">Answer: {q.correct_answer}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
