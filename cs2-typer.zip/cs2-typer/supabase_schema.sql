-- ============================================================
-- CS2 Typer — Supabase Database Schema
-- Run this in your Supabase SQL Editor (Dashboard → SQL Editor)
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ────────────────────────────────────────────────────────────
-- TABLES
-- ────────────────────────────────────────────────────────────

create table if not exists public.users (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null unique,
  username    text not null,
  avatar      text,
  points      integer not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists public.matches (
  id          uuid primary key default uuid_generate_v4(),
  team_a      text not null,
  team_b      text not null,
  start_time  timestamptz not null,
  status      text not null default 'upcoming'
                check (status in ('upcoming', 'live', 'finished')),
  result      text,           -- team name of winner
  score_a     integer,        -- team_a score
  score_b     integer,        -- team_b score
  settled     boolean not null default false,
  created_at  timestamptz not null default now()
);

create table if not exists public.bets (
  id                   uuid primary key default uuid_generate_v4(),
  user_id              uuid not null references public.users(id) on delete cascade,
  match_id             uuid not null references public.matches(id) on delete cascade,
  predicted_winner     text not null,
  predicted_score_a    integer,
  predicted_score_b    integer,
  points_awarded       integer,        -- null = not yet settled
  winner_correct       boolean,
  exact_score_correct  boolean,
  created_at           timestamptz not null default now(),
  unique(user_id, match_id)            -- one bet per user per match
);

create table if not exists public.bonus_questions (
  id             uuid primary key default uuid_generate_v4(),
  match_id       uuid not null references public.matches(id) on delete cascade,
  question       text not null,
  correct_answer text not null,
  created_at     timestamptz not null default now()
);

create table if not exists public.bonus_answers (
  id             uuid primary key default uuid_generate_v4(),
  user_id        uuid not null references public.users(id) on delete cascade,
  question_id    uuid not null references public.bonus_questions(id) on delete cascade,
  answer         text not null,
  points_awarded integer,        -- null = not yet settled
  created_at     timestamptz not null default now(),
  unique(user_id, question_id)   -- one answer per user per question
);

-- ────────────────────────────────────────────────────────────
-- INDEXES
-- ────────────────────────────────────────────────────────────

create index if not exists idx_bets_user_id    on public.bets(user_id);
create index if not exists idx_bets_match_id   on public.bets(match_id);
create index if not exists idx_bets_winner_correct on public.bets(winner_correct);
create index if not exists idx_bonus_answers_user  on public.bonus_answers(user_id);
create index if not exists idx_matches_start_time  on public.matches(start_time);
create index if not exists idx_matches_status       on public.matches(status);

-- ────────────────────────────────────────────────────────────
-- STORED FUNCTION: atomic point increment
-- Used by settlement logic to safely add points to a user
-- ────────────────────────────────────────────────────────────

create or replace function increment_user_points(uid uuid, pts integer)
returns void
language sql
security definer
as $$
  update public.users
  set points = points + pts
  where id = uid;
$$;

-- ────────────────────────────────────────────────────────────
-- ROW LEVEL SECURITY
-- The backend uses the SERVICE ROLE key which bypasses RLS.
-- These policies are for direct Supabase client access safety.
-- ────────────────────────────────────────────────────────────

alter table public.users          enable row level security;
alter table public.matches         enable row level security;
alter table public.bets            enable row level security;
alter table public.bonus_questions enable row level security;
alter table public.bonus_answers   enable row level security;

-- Users: anyone can read, only owner can update own row
create policy "Users are publicly readable"
  on public.users for select using (true);

create policy "Users can update their own profile"
  on public.users for update using (auth.uid() = id);

create policy "Users can insert their own profile"
  on public.users for insert with check (auth.uid() = id);

-- Matches: publicly readable, only service role can write (backend)
create policy "Matches are publicly readable"
  on public.matches for select using (true);

-- Bets: users can see their own, insert/update their own
create policy "Users can see their own bets"
  on public.bets for select using (auth.uid() = user_id);

create policy "Users can insert their own bets"
  on public.bets for insert with check (auth.uid() = user_id);

create policy "Users can update their own bets"
  on public.bets for update using (auth.uid() = user_id);

-- Bonus questions: publicly readable
create policy "Bonus questions are publicly readable"
  on public.bonus_questions for select using (true);

-- Bonus answers: users can see/manage their own
create policy "Users can see their own bonus answers"
  on public.bonus_answers for select using (auth.uid() = user_id);

create policy "Users can insert their own bonus answers"
  on public.bonus_answers for insert with check (auth.uid() = user_id);

create policy "Users can update their own bonus answers"
  on public.bonus_answers for update using (auth.uid() = user_id);

-- ────────────────────────────────────────────────────────────
-- SAMPLE DATA (optional — remove in production)
-- ────────────────────────────────────────────────────────────

-- insert into public.matches (team_a, team_b, start_time, status)
-- values
--   ('NaVi', 'Astralis', now() + interval '2 days', 'upcoming'),
--   ('FaZe', 'Vitality', now() + interval '4 days', 'upcoming'),
--   ('ENCE', 'G2', now() - interval '1 day', 'finished');
